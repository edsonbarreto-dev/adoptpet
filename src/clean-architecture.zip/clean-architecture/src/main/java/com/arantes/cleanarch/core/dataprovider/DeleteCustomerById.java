package com.arantes.cleanarch.core.dataprovider;

public interface DeleteCustomerById {

    void delete(final String id);

}
