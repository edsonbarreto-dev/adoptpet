package com.arantes.cleanarch.core.dataprovider;

import com.arantes.cleanarch.core.domain.Customer;

public interface InsertCustomer {

    void insert(Customer customer);

}
