package com.arantes.cleanarch.core.dataprovider;

public interface SendCpfForValidation {

    void send(final String cpf);

}
