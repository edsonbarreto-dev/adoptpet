package com.arantes.cleanarch.core.dataprovider;

import com.arantes.cleanarch.core.domain.Customer;

public interface UpdateCustomer {

    void update(Customer customer);

}
