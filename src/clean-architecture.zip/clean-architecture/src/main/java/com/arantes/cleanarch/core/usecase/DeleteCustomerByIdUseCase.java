package com.arantes.cleanarch.core.usecase;

public interface DeleteCustomerByIdUseCase {

    void delete(final String id);

}
